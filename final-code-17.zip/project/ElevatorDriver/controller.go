package ElevatorDriver

import (
	"fmt"
	"project/config"
	"project/elevio"
	"time"
)

func ElevatorController(
	newOrderC <-chan Orders,
	updatedElevatorStateC chan<- Elevator,
	deliveredOrderC chan<- elevio.ButtonEvent,
	elevator Elevator,
) {

	newFloorC := make(chan int, config.Buffer)
	openDoorC := make(chan bool, config.Buffer)
	doorObstructedc := make(chan bool, config.Buffer)
	doorClosingc := make(chan bool, config.Buffer)

	elevatorMotorTimer := time.NewTimer(config.ElevatorMotorTime)
	elevatorMotorTimer.Stop()

	recoveryTicker := time.NewTicker(config.RecoveryTicker)
	recoveryTicker.Stop()

	var orders Orders

	go elevatorDoorController(openDoorC, doorObstructedc, doorClosingc)
	go elevio.PollFloorSensor(newFloorC)

	for {
		select {
		case floor := <-newFloorC:
			handleFloorArrival(&elevator, orders, openDoorC, deliveredOrderC, elevatorMotorTimer, floor)
			recoveryTicker.Stop()
			elevator.MotorStop = false
			updatedElevatorStateC <- elevator

		case <-doorClosingc:
			handleDoorClosing(&elevator, orders, openDoorC, deliveredOrderC, elevatorMotorTimer)
			updatedElevatorStateC <- elevator
		case orders = <-newOrderC:
			handleNewOrder(&elevator, orders, openDoorC, deliveredOrderC, elevatorMotorTimer)
			updatedElevatorStateC <- elevator

		case <-elevatorMotorTimer.C:
			fmt.Println("Gets motorstop")
			elevator.MotorStop = true
			recoveryTicker.Reset(config.RecoveryTicker)
			updatedElevatorStateC <- elevator

		case obstruction := <-doorObstructedc:
			handleObstruction(&elevator, obstruction, openDoorC)
			updatedElevatorStateC <- elevator

		case <-recoveryTicker.C:
			elevio.SetMotorDirection(elevator.Direction.toMD())
		}
	}
}
